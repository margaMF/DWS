<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Gestor de torneos</title>
        <link rel="stylesheet" href="../../css/gestionTorneosVista.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    </head>
    <body>
        <div class="contenedor">
            <div class="menu">
                <div class="contenedorBotones">
                    <a href="logout"  class="botonSesion">Cerrar sesión</a>
                </div>
            </div>

            <div class="contenedorFormulario">
                <form action="">
                    <label for="nombre">Nombre:</label>
                    <input type="text" id="usuario" name="usuario" value="" class="cajaNombre"><br><br>

                    <label for="fecha">Fecha:</label>
                    <input type="text" name="fecha" id="fecha" value="" class="cajaFecha"><br><br>

                    <input type="submit" name="enviar" value="Crear torneo" class="botonEnviar"><br>
                </form>
            </div>
        <div>
    </body>
</html>